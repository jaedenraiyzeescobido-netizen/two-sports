require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const API = "https://api.statsradar.io/v1";
const KEY = process.env.STATSRADAR_KEY;

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

let cachedLeagueId = null;
let leagueCacheAt = 0;

async function statsRadar(pathname) {
  if (!KEY || KEY === "PASTE_YOUR_API_KEY_HERE") {
    const err = new Error("Add your StatsRadar API key to the .env file.");
    err.status = 503;
    throw err;
  }
  const response = await fetch(API + pathname, {
    headers: { Authorization: `Bearer ${KEY}`, Accept: "application/json" }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok || body.errorCode) {
    const err = new Error(body.errorCode || `StatsRadar returned HTTP ${response.status}`);
    err.status = response.status || 502;
    throw err;
  }
  return body.data;
}

async function getPbaLeagueId() {
  if (cachedLeagueId && Date.now() - leagueCacheAt < 60 * 60 * 1000) return cachedLeagueId;
  const leagues = await statsRadar("/leagues");
  const pba = (leagues || []).find(x => String(x.name).toLowerCase().includes("pba"));
  if (!pba) {
    const err = new Error("Your API key does not currently return a PBA league.");
    err.status = 404;
    throw err;
  }
  cachedLeagueId = pba.leagueId;
  leagueCacheAt = Date.now();
  return cachedLeagueId;
}

function sendError(res, err) {
  res.status(err.status || 502).json({
    error: err.message || "Data provider request failed",
    hint: err.status === 401 ? "Check that your API key is valid and approved." :
          err.status === 429 ? "Daily API request quota reached. Try again after the quota resets." : undefined
  });
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, providerConfigured: !!KEY && KEY !== "PASTE_YOUR_API_KEY_HERE" });
});

// Matches endpoint: StatsRadar allows a maximum seven-day window per request.
app.get("/api/pba/matches", async (req, res) => {
  try {
    const now = new Date();
    const from = req.query.from || new Date(now.getTime() - 3 * 86400000).toISOString();
    const until = req.query.until || new Date(now.getTime() + 4 * 86400000).toISOString();
    const start = Date.parse(from), end = Date.parse(until);
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start || end - start > 7 * 86400000) {
      return res.status(400).json({ error: "Provide valid from/until dates no more than 7 days apart." });
    }
    const leagueId = await getPbaLeagueId();
    const data = await statsRadar(`/leagues/${encodeURIComponent(leagueId)}/matches?from=${encodeURIComponent(new Date(start).toISOString())}&until=${encodeURIComponent(new Date(end).toISOString())}`);
    res.json({ data });
  } catch (err) { sendError(res, err); }
});

app.get("/api/pba/teams", async (req, res) => {
  try {
    const leagueId = await getPbaLeagueId();
    res.json({ data: await statsRadar(`/leagues/${encodeURIComponent(leagueId)}/teams`) });
  } catch (err) { sendError(res, err); }
});

app.get("/api/pba/teams/:teamId/players", async (req, res) => {
  try {
    const leagueId = await getPbaLeagueId();
    res.json({ data: await statsRadar(`/leagues/${encodeURIComponent(leagueId)}/teams/${encodeURIComponent(req.params.teamId)}/players`) });
  } catch (err) { sendError(res, err); }
});

app.get("/api/pba/matches/:matchId", async (req, res) => {
  try {
    res.json({ data: await statsRadar(`/matches/${encodeURIComponent(req.params.matchId)}`) });
  } catch (err) { sendError(res, err); }
});

app.listen(PORT, "0.0.0.0", () => console.log(`Two Sports listening on port ${PORT}`));
