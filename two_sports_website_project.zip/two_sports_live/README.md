# Two Sports — PBA website starter

This is a deployable Node/Express website project. It serves the mobile-friendly Two Sports page and proxies PBA data requests through a server so the provider API key is not exposed in browser code.

## Before deployment

- You need a StatsRadar API key whose account is authorized for PBA data. Do not put the key in `public/index.html` or commit it to Git.
- The API paths and response fields in this starter are assumptions based on the provider integration draft and must be verified against the API access/docs for your account. It has not been verified end-to-end with your private key.
- The page polls the backend every 10 seconds. That does not guarantee real-time data: provider plan delays, quotas, and coverage still apply.

## Deploy as a website with Render

1. Upload this entire project folder to a GitHub repository. Keep `.env` out of the repository; `.gitignore` excludes it.
2. In Render, choose **New → Web Service**, then connect the repository. You can also use the included `render.yaml` Blueprint if offered.
3. Use these settings if asked:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
4. In the Render service's **Environment** settings, add `STATSRADAR_KEY` with your private API key. Never put the key in a public file or chat.
5. Deploy. When it succeeds, Render gives the site a public `onrender.com` address. Share that website address with your friend; they do not need the project files.

Official deployment guide: https://render.com/docs/deploy-node-express-app
Environment variables guide: https://render.com/docs/configure-environment-variables

## Run locally (optional)

Requires Node.js 18 or newer. Copy `.env.example` to `.env`, add your key, then run:

```bash
npm install
npm start
```

Open `http://localhost:3000`.

## Current features and limitations

- PBA match list, team directory, team rosters, and match detail request endpoints.
- Match list refreshes every 10 seconds; team data refreshes every 15 minutes.
- No fabricated live scores are shown. If the provider does not return data or access is not enabled, the page displays an error.
- Standings, news, play-by-play, and season leaderboards are not implemented in this starter.
